app.common = {
    init: function(){
  
    },
    finalize: function(){

    }
};